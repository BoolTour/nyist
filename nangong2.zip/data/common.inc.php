<?php
//数据库连接信息
$cfg_dbhost = '87noc5pa.2321lan.dnstoo.com:3306';
$cfg_dbname = 'nangong2';
$cfg_dbuser = 'nangong2_f';
$cfg_dbpwd = 'linuxcxs123';
$cfg_dbprefix = 'dede_';
$cfg_db_language = 'utf8';


?>