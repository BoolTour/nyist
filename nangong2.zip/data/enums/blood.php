<?php
global $em_bloods;
$em_bloods = array();
$em_bloods['1'] = 'A';
$em_bloods['2'] = 'B';
$em_bloods['3'] = 'AB';
$em_bloods['4'] = 'O';
?>